
// The Cloud Functions for Firebase SDK to create Cloud Functions and setup triggers.
const functions = require('firebase-functions');

// The Firebase Admin SDK to access the Firebase Realtime Database.
const admin = require('firebase-admin');
admin.initializeApp();

exports.dataBaseUpdateNotification = functions.database.ref('hebrew').onWrite(event => {
    
    var payload = {
      notification: {
        title: "עדכון במסד השאלות",
        body: "התבצע עדכון שאלות במסד או נוספו שאלות חדשות"
      }
    };
    console.log("Sending update message..");
    var topic = "db_updates";
    admin.messaging().sendToTopic(topic, payload);
  });
