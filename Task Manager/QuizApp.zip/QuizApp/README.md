# QuizApp


A trivia application that fetch data (Questions and answers) from Firebase. 


**Plugins used**


- [Firebase](https://firebase.google.com/) - Question's database.

- [Zoomage](https://github.com/jsibbold/zoomage) - A simple pinch-to-zoom ImageView library for Android with an emphasis on a smooth and natural feel.

- [Android Universal Image Loader](https://github.com/nostra13/Android-Universal-Image-Loader) 
