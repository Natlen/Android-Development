package com.rkcodesolution.quizapp;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import static com.rkcodesolution.quizapp.QuizApp.QATAG;

public class BatteryBroadcastReceiver extends BroadcastReceiver {
    private final static int THRESHOLD = 50;
    private static boolean sToRegister = true;  // for orientation changes.
    private Activity mActivity;
    private BroadcastReceiver mReceiver;

    /**
     * Register via constructor to battery changes.
     */
    public BatteryBroadcastReceiver(Activity activity){
        mActivity = activity;
        mReceiver = this;
        if (mActivity != null && sToRegister) {
            mActivity.registerReceiver(this, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        } else {
            Log.e(QATAG, "Null context was provided to BatteryBroadcastReceiver.");
        }
    }

    /**
     * On battery level change handler function,
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
        String msg = context.getString(R.string.low_batt_part_A) +
                THRESHOLD +
                context.getString(R.string.low_batt_part_B);

        if (level < THRESHOLD) {
            new AlertDialog.Builder(mActivity)
                    .setTitle(mActivity.getString(R.string.low_battery))
                    .setMessage(msg)
                    .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            mActivity.finish();       // exit app.
                        }
                    })
                    .setNegativeButton(R.string.no, new DialogInterface.OnClickListener(){
                        public void onClick(DialogInterface dialog, int which) {
                            sToRegister = false;        // for orientation changes.
                            try{
                                mActivity.unregisterReceiver(mReceiver);
                            } catch(Exception e) {
                                // Don't care
                            }
                        }
                    })
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show();
        }
    }

}