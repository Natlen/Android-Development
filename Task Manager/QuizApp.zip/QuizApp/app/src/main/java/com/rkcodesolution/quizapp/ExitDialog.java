package com.rkcodesolution.quizapp;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;

public class ExitDialog extends DialogFragment {
    private IExitListener mListener;

    /**
     * Create Exit Dialog.
     * If user choose to exit, onExitPressed function will be called.
     */
    @Override
    @NonNull
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return new AlertDialog.Builder(getContext())
                .setTitle(R.string.exit_dialog_title)
                .setMessage(R.string.exit_dialog_text)
                .setPositiveButton(R.string.dialog_yes,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                mListener.onExitPressed();
                                dismiss();
                            }
                        }
                )
                .setNegativeButton(R.string.dialog_no,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dismiss();
                            }
                        }
                )
                .create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof IExitListener) {
            mListener = (IExitListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement IExitListener");
        }
    }

    /**
     * Interface for the exit fragment.
     */
    public interface IExitListener {
        void onExitPressed();
    }
}
